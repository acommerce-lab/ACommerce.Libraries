namespace ACommerce.Authentication.TwoFactor.Nafath;

public enum NafathMode
{
	Production,
	Test
}

