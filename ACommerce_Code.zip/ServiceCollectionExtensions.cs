namespace ACommerce.Authentication.AspNetCore.Controllers;

public static class ServiceCollectionExtensions
{
	/// <summary>
	/// Adds ACommerce authentication controllers
	/// </summary>
	//public static IServiceCollection AddACommerceAuthenticationControllers(
	//	this IServiceCollection services)
	//{
	//	services.AddControllers()
	//		.AddApplicationPart(typeof(Controllers.AuthenticationController).Assembly);

	//	return services;
	//}
}

