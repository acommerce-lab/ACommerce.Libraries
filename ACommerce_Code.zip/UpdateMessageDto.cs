namespace ACommerce.Chats.Abstractions.DTOs;

/// <summary>
/// ?????? ????? ?????
/// </summary>
public class UpdateMessageDto
{
	public required string Content { get; set; }
}

