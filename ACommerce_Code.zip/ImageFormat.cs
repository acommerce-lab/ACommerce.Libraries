// Enums/ImageFormat.cs
namespace ACommerce.Files.Abstractions.Enums;

// Enums/ImageFormat.cs
public enum ImageFormat
{
	Jpeg = 1,
	Png = 2,
	Gif = 3,
	WebP = 4,
	Bmp = 5
}

