namespace ACommerce.Accounting.Core.Enums;

/// <summary>
/// ????? ??????
/// </summary>
public enum AccountNature
{
	/// <summary>
	/// ???? (Debit)
	/// </summary>
	Debit = 1,

	/// <summary>
	/// ???? (Credit)
	/// </summary>
	Credit = 2
}

