// DTOs/Roles/AddUserToRoleDto.cs
namespace ACommerce.Authentication.AspNetCore.DTOs.Roles;

// DTOs/Roles/AddUserToRoleDto.cs
/// <summary>
/// DTO ?????? ?????? ????
/// </summary>
public class AddUserToRoleDto
{
	/// <summary>
	/// ???? ????????
	/// </summary>
	public required string UserId { get; init; }
}

