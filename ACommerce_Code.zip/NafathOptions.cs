namespace ACommerce.Auth.Authentica.Domain.DTOs;

public class NafathOptions
{
	public string? BaseUrl { get; set; }
	public string? ClientId { get; set; }
	public string? ClientSecret { get; set; }
}

